from PySide6.QtWidgets import (
    QMainWindow,
    QWidget,
    QVBoxLayout,
    QPushButton,
    QMessageBox,
    QGridLayout,
    QLabel,
    QHBoxLayout,
    QFrame,
    QApplication,
)
from PySide6.QtCore import QTimer, Qt, QRectF, QPointF, QPropertyAnimation, QSequentialAnimationGroup
from PySide6.QtGui import QPainter, QColor, QBrush, QPen, QFont, QPolygonF
import random
from collections import deque


# --- Classe Passenger ---whw
class Passenger:
    """
    Representa um passageiro esperando para embarcar em um autocarro.
    """

    def __init__(self, color: str, initial_position: tuple = None):
        self.color = color
        self.current_position = (
            initial_position
        )
        self.is_boarded = False

    def __repr__(self):
        return f"Passenger(Color: {self.color})"


# --- Classe Bus ---
class Bus:
    """
    Representa um autocarro no jogo, com sua capacidade, cor, direção,
    posição atual e passageiros a bordo.
    """

    def __init__(self, capacity: int, color: str, direction: str, initial_position: tuple):
        self.capacity = capacity
        self.color = color
        self.direction = (
            direction
        )  # 'up', 'down', 'left', ou 'right'
        self.current_position = (
            initial_position
        )
        self.passengers = []
        self.is_at_boarding_slot = (
            False
        )
        self.animated_position = (
            None # For smooth transitions
        )


        if capacity == 4:
            self._length = 2
        elif capacity == 6:
            self._length = 3
        elif capacity == 8:
            self._length = 4
        elif capacity == 12:
            self._length = 5
        else: # Default if capacity is not in predefined list
            self._length = 2 

        # Definir o size com base na direção específica
        if self.direction in ["left", "right"]: # Horizontal bus
            self.size = (1, self._length)
        else: # "up", "down" - Vertical bus
            self.size = (self._length, 1)

    def get_occupied_cells(self):
        """Retorna uma lista de tuplas (row, col) representando as células ocupadas pelo autocarro."""
        occupied_cells = []
        if self.current_position is None:
            return []
        start_row, start_col = self.current_position
        rows_occupied, cols_occupied = self.size

        for r_offset in range(rows_occupied):
            for c_offset in range(cols_occupied):
                occupied_cells.append((start_row + r_offset, start_col + c_offset))
        return occupied_cells

    def __repr__(self):
        return f"Bus(Color: {self.color}, Cap: {self.capacity}, Dir: {self.direction}, Pos: {self.current_position}, Size: {self.size})"

    def can_board_passenger(self, passenger: "Passenger"):
        """Verifica se o autocarro pode embarcar um passageiro."""
        # Usa 'in' para verificar se a cor do passageiro está contida na cor do autocarro.
        # Ambas as strings são convertidas para minúsculas para uma comparação case-insensitive.
        return len(self.passengers) < self.capacity and passenger.color.lower() in self.color.lower()

    def add_passenger(self, passenger: "Passenger"):
        """Embarca um passageiro no autocarro."""
        if self.can_board_passenger(passenger):
            self.passengers.append(passenger)
            return True
        return False

    def is_full(self):
        """Verifica se o autocarro está com a capacidade máxima de passageiros."""
        return len(self.passengers) == self.capacity

    def all_passengers_match_color(self):
        """Verifica se todos os passageiros a bordo são da mesma cor (a cor do autocarro)."""
        if not self.passengers:
            return False # A bus with no passengers isn't "full and matching"
        # Ajustado para considerar que a cor do passageiro deve estar contida na cor do autocarro
        return all(p.color.lower() in self.color.lower() for p in self.passengers)

    def get_off_passengers(self):
        """Faz com que todos os passageiros desçam do autocarro."""
        num_passengers_off = len(self.passengers)
        self.passengers = []
        return num_passengers_off


# --- Classe Board ---
class Board:
    """
    Representa o tabuleiro do jogo Bus Park, gerenciando a posição dos autocarros,
    passageiros e slots de embarque.
    """

    def __init__(self, rows: int, cols: int, num_boarding_slots: int = 6):
        self.rows = rows
        self.cols = cols
        self.grid = [[None for _ in range(cols)] for _ in range(rows)]
        self.boarding_slots = {}
        self.initial_num_boarding_slots = num_boarding_slots
        self.passengers_waiting = []
        self.all_buses = []

        self._initialize_boarding_slots()

    def _initialize_boarding_slots(self):
        """
        Inicializa os slots de embarque seguidos numa única borda (por exemplo, topo).
        """
        min_slots = 4
        max_slots = 8
        num_slots = min(self.initial_num_boarding_slots, random.randint(min_slots, max_slots))
        self.num_boarding_slots = num_slots

        # Borda escolhida: TOPO (-1, col)
        max_start_col = self.cols - num_slots
        if max_start_col < 0:
            print("Tabuleiro demasiado pequeno para colocar slots seguidos na mesma borda.")
            self.boarding_slots = {}
            return

        start_col = random.randint(0, max_start_col)
        slot_positions = [(-1, c) for c in range(start_col, start_col + num_slots)]

        self.boarding_slots = {pos: None for pos in slot_positions}
        print(f"Slots de embarque seguidos no topo: {slot_positions}")


    def is_area_free(self, start_position: tuple, bus_size: tuple, bus_to_ignore=None):
        """
        Verifica se a área definida por start_position e bus_size está livre NO GRID PRINCIPAL.
        Ignora o 'bus_to_ignore' ao verificar colisões.
        """
        start_row, start_col = start_position
        rows_to_check, cols_to_check = bus_size

        for r_offset in range(rows_to_check):
            for c_offset in range(cols_to_check):
                current_row = start_row + r_offset
                current_col = start_col + c_offset

                # 1. Verifica se a célula está dentro dos limites do grid principal
                if 0 <= current_row < self.rows and 0 <= current_col < self.cols:
                    # Se sim, verifica se está ocupada por outro autocarro no grid
                    if (
                        self.grid[current_row][current_col] is not None
                        and self.grid[current_row][current_col] != bus_to_ignore
                    ):
                        return False  # Célula do grid ocupada
                # 2. Se a célula está fora dos limites do grid principal, então não está "livre" para colocar o autocarro lá DENTRO do grid
                else:
                    return False # Fora do grid principal
        return True

    def is_boarding_slot(self, position: tuple):
        """Verifica se uma posição é um slot de embarque."""
        return position in self.boarding_slots

    def _clear_bus_from_all_current_positions(self, bus: "Bus"):
        """
        Remove o autocarro de sua posição atual no grid principal OU no slot de embarque.
        Usado como um auxiliar antes de reposicionar o autocarro.
        """
        if bus.current_position:
            start_row, start_col = bus.current_position
            rows_occupied, cols_occupied = bus.size

            # Tenta remover do grid principal
            for r_offset in range(rows_occupied):
                for c_offset in range(cols_occupied):
                    r, c = start_row + r_offset, start_col + c_offset
                    if (
                        0 <= r < self.rows
                        and 0 <= c < self.cols
                        and self.grid[r][c] == bus
                    ):
                        self.grid[r][c] = None

            # Tenta remover do slot de embarque (se o autocarro estava lá)
            if (
                bus.current_position in self.boarding_slots
                and self.boarding_slots[bus.current_position] == bus
            ):
                self.boarding_slots[bus.current_position] = None
                bus.is_at_boarding_slot = False


    def place_bus(self, bus: "Bus", position: tuple):
        """
        Coloca um autocarro no tabuleiro na posição dada.
        Gerencia o grid principal e os slots de embarque.
        """
        # Save original position to restore if placement fails
        original_position = bus.current_position
        self._clear_bus_from_all_current_positions(bus)

        bus.current_position = position

        if self.is_boarding_slot(position):
            if self.boarding_slots[position] is None: # <--- CRITICAL CHECK: only one bus per slot
                self.boarding_slots[position] = bus
                bus.is_at_boarding_slot = True
                if bus not in self.all_buses:
                    self.all_buses.append(bus)
                return True
            else:
                bus.current_position = original_position # Restore original position
                # Re-place the bus at its original position if it was there
                if original_position: # Check if bus had an original position
                    if not self.is_boarding_slot(original_position):
                        # If original was in grid, put it back
                        for r, c in bus.get_occupied_cells():
                            if 0 <= r < self.rows and 0 <= c < self.cols:
                                self.grid[r][c] = bus
                    else:
                        # If original was in a slot, put it back
                        self.boarding_slots[original_position] = bus
                        bus.is_at_boarding_slot = True
                return False
        else: # Posição no grid principal
            if self.is_area_free(position, bus.size, bus_to_ignore=bus):
                for r, c in bus.get_occupied_cells():
                    if 0 <= r < self.rows and 0 <= c < self.cols:
                        self.grid[r][c] = bus
                bus.is_at_boarding_slot = False
                if bus not in self.all_buses:
                    self.all_buses.append(bus)
                return True
            else:
                bus.current_position = original_position # Restore original position
                # Re-place the bus at its original position if it was there
                if original_position: # Check if bus had an original position
                    if not self.is_boarding_slot(original_position):
                        # If original was in grid, put it back
                        for r, c in bus.get_occupied_cells():
                            if 0 <= r < self.rows and 0 <= c < self.cols:
                                self.grid[r][c] = bus
                    else:
                        # If original was in a slot, put it back
                        self.boarding_slots[original_position] = bus
                        bus.is_at_boarding_slot = True
                return False

    def get_bus_at_position(self, position: tuple):
        """
        Retorna o objeto Bus na posição dada, ou None se não houver.
        Verifica tanto o grid principal quanto os slots de embarque.
        """
        r, c = position

        # Check if clicked position is part of a bus in the main grid
        if 0 <= r < self.rows and 0 <= c < self.cols:
            bus_in_grid = self.grid[r][c]
            if bus_in_grid is not None:
                return bus_in_grid

        # Check if clicked position is a boarding slot and contains a bus
        if position in self.boarding_slots:
            return self.boarding_slots[position]

        return None


    def _can_bus_reach_any_free_slot(self, bus_to_check: "Bus"):
        """
        Verifica se um dado autocarro pode alcançar QUALQUER slot de embarque livre.
        Primeiro, verifica se há algum slot livre.
        Segundo, usa BFS para verificar se o autocarro pode alcançar uma *fronteira de saída*,
        e se dessa fronteira há um slot livre adjacente.
        """
        # 1. Verifica se há algum slot livre primeiro
        free_slots = [s for s, b in self.boarding_slots.items() if b is None]
        if not free_slots:
            return False

        # 2. Se o autocarro já está num slot, ele está "pronto" ou "já alcançou"
        if bus_to_check.is_at_boarding_slot:
            return True

        original_pos = bus_to_check.current_position
        if original_pos is None:
            return False

        queue = deque([(original_pos, [original_pos])])
        visited = {original_pos}

        # Simula a remoção do autocarro para calcular caminhos dentro do grid
        self._clear_bus_from_all_current_positions(bus_to_check)

        path_to_exit_border = None
        while queue:
            current_pos, path = queue.popleft()

            if len(path) > (self.rows * self.cols) * 2: # Limit to prevent infinite loops for complex paths
                break

            # MODIFICAÇÃO AQUI: A condição de sucesso do BFS AGORA verifica se o autocarro
            # está numa fronteira E se há um slot adjacente livre.

            can_exit_from_current_pos = False
            start_r, start_c = current_pos
            rows_bus, cols_bus = bus_to_check.size

            # Check if any part of the bus at 'current_pos' is touching any border
            # This logic must be robust to consider the bus's dimensions
            
            bus_at_border = False
            # Check top edge contact
            if start_r == 0: bus_at_border = True
            # Check bottom edge contact
            if start_r + rows_bus - 1 == self.rows - 1: bus_at_border = True
            # Check left edge contact
            if start_c == 0: bus_at_border = True
            # Check right edge contact
            if start_c + cols_bus - 1 == self.cols - 1: bus_at_border = True
            
            if bus_at_border:
                # If the bus touches any border, check if there's *any* free slot adjacent to *any* part of the bus
                for slot_pos, bus_in_slot in self.boarding_slots.items():
                    if bus_in_slot is None: # If the slot is free
                        slot_r, slot_c = slot_pos

                        is_slot_truly_adjacent = False

                        # Check for adjacency to top border slots (slot_r == -1)
                        if slot_r == -1 and (start_c <= slot_c < start_c + cols_bus):
                             is_slot_truly_adjacent = True
                        # Check for adjacency to bottom border slots (slot_r == self.rows)
                        elif slot_r == self.rows and (start_c <= slot_c < start_c + cols_bus):
                            is_slot_truly_adjacent = True
                        # Check for adjacency to left border slots (slot_c == -1)
                        elif slot_c == -1 and (start_r <= slot_r < start_r + rows_bus):
                            is_slot_truly_adjacent = True
                        # Check for adjacency to right border slots (slot_c == self.cols)
                        elif slot_c == self.cols and (start_r <= slot_r < start_r + rows_bus):
                            is_slot_truly_adjacent = True
                        
                        # Handle corner cases for slots - when bus is in a corner of the main grid
                        # Bus top-left (0,0), slot (-1,-1)
                        if (start_r == 0 and start_c == 0) and (slot_r == -1 and slot_c == -1):
                            is_slot_truly_adjacent = True
                        # Bus top-right (0, cols-bus_cols), slot (-1, cols)
                        elif (start_r == 0 and start_c + cols_bus - 1 == self.cols - 1) and (slot_r == -1 and slot_c == self.cols):
                            is_slot_truly_adjacent = True
                        # Bus bottom-left (rows-bus_rows, 0), slot (rows, -1)
                        elif (start_r + rows_bus - 1 == self.rows - 1 and start_c == 0) and (slot_r == self.rows and slot_c == -1):
                            is_slot_truly_adjacent = True
                        # Bus bottom-right (rows-bus_rows, cols-bus_cols), slot (rows, cols)
                        elif (start_r + rows_bus - 1 == self.rows - 1 and start_c + cols_bus - 1 == self.cols - 1) and (slot_r == self.rows and slot_c == self.cols):
                            is_slot_truly_adjacent = True

                        if is_slot_truly_adjacent:
                            path_to_exit_border = path + [slot_pos] # Inclui o slot no caminho para animação
                            can_exit_from_current_pos = True
                            break # Encontrou um caminho e um slot livre para sair

            if can_exit_from_current_pos:
                break # Encontrou um caminho para uma posição de saída com um slot livre

            # Se não é uma posição de saída ou não há slot livre adjacente, continua explorando dentro do grid
            
            # Temporariamente colocamos o autocarro na current_pos para calcular os "next_moves" a partir dali
            self.place_bus(bus_to_check, current_pos)
            
            # get_possible_moves SÓ RETORNA MOVS DENTRO DO GRID PRINCIPAL
            possible_next_positions = self.get_possible_moves(bus_to_check)
            
            # Agora limpamos de novo para o BFS continuar sem que o autocarro bloqueie as suas próprias células
            self._clear_bus_from_all_current_positions(bus_to_check)

            for next_pos in possible_next_positions:
                if next_pos not in visited:
                    visited.add(next_pos)
                    queue.append((next_pos, path + [next_pos]))

        # Re-coloca o autocarro na sua posição original após a simulação
        self.place_bus(bus_to_check, original_pos)

        return path_to_exit_border is not None # Retorna True se encontrou um caminho para um slot livre, False caso contrário


    def generate_initial_configuration(self, num_buses: int, max_attempts=50):
        """
        Gera uma configuração inicial aleatória de autocarros e passageiros,
        garantindo que não esteja em deadlock imediato.
        Ajusta o número de passageiros para corresponder à capacidade total dos autocarros.
        """
        for attempt_config in range(max_attempts):
            print(
                f"\n--- Tentativa de geração de configuração: {attempt_config + 1}/{max_attempts} ---"
            )

            # Reset board for new attempt
            self.grid = [[None for _ in range(self.cols)] for _ in range(self.rows)]
            self.passengers_waiting = []
            self.all_buses = []
            self.boarding_slots = {} # Reset slots as well
            self._initialize_boarding_slots()
            print(f"Slots limpos para nova configuração: {self.boarding_slots}")


            # Usar uma lista de cores mais genéricas para os passageiros, mas as do autocarro podem ser mais específicas.
            colors = [
                "red", "blue", "green", "purple", "orange", "cyan", "magenta",
            ]
            bus_capacities = [4, 6, 8, 12]
            # MODIFICAÇÃO AQUI: Novas direções possíveis
            bus_directions = ["up", "down", "left", "right"] 

            placed_buses_count = 0
            placement_attempts = 0
            max_placement_attempts_per_bus = 100

            buses_to_place = []

            while (
                placed_buses_count < num_buses
                and placement_attempts < num_buses * max_placement_attempts_per_bus
            ):
                capacity = random.choice(bus_capacities)
                color = random.choice(colors)
                if random.random() < 0.2: # 20% chance to be "purple_and_lilac"
                    color = "purple_and_lilac"
                
                # Escolher entre as 4 direções
                direction = random.choice(bus_directions)

                bus = Bus(capacity, color, direction, None)

                valid_spawn_cells = []
                for r in range(self.rows):
                    for c in range(self.cols):
                        if self.is_area_free((r, c), bus.size, bus_to_ignore=None):
                            valid_spawn_cells.append((r, c))

                random.shuffle(valid_spawn_cells)

                found_position_for_current_bus = False
                for r_start, c_start in valid_spawn_cells:
                    # Temporarily clear to place, then try to place. place_bus handles restoring if it fails.
                    if self.place_bus(bus, (r_start, c_start)):
                        placed_buses_count += 1
                        buses_to_place.append(bus)
                        found_position_for_current_bus = True
                        break

                if not found_position_for_current_bus:
                    pass # This bus couldn't be placed, try another random one or a different position
                placement_attempts += 1

            if placed_buses_count < num_buses:
                print(
                    f"Aviso: Não foi possível colocar todos os {num_buses} autocarros nesta tentativa. Apenas {placed_buses_count} foram colocados. Retentando..."
                )
                continue

            self.all_buses = buses_to_place

            # Calculate total capacity of placed buses
            total_bus_capacity = sum(b.capacity for b in self.all_buses)
            
            # Generate passengers based on total bus capacity
            self.passengers_waiting = []
            # Ensure passenger colors match existing bus colors to make the game solvable
            available_bus_colors_for_passengers = list(set(c for b in self.all_buses for c in b.color.split('_and_'))) # Split "purple_and_lilac"
            
            # --- MODIFICAÇÃO AQUI: FILTRAR "yellow" se por acaso ainda existisse ---
            available_bus_colors_for_passengers = [color for color in available_bus_colors_for_passengers if color != "yellow"]
            # --- FIM DA MODIFICAÇÃO ---

            for _ in range(total_bus_capacity):
                if available_bus_colors_for_passengers: # Only add if there are bus colors
                    color = random.choice(available_bus_colors_for_passengers) 
                    self.passengers_waiting.append(Passenger(color))
            
            random.shuffle(self.passengers_waiting) # Shuffle passengers

            if not self.passengers_waiting and total_bus_capacity > 0:
                print("ERRO: Configuração gerada sem passageiros esperando, mas autocarros com capacidade. Retentando...")
                continue # This means all buses have 0 capacity, which is unexpected for the game.

            if not self.passengers_waiting: # This is a valid state if total_bus_capacity is 0 (unlikely for game)
                print("Configuração gerada: Sem passageiros esperando. (OK)")


            can_any_bus_reach_a_slot = False
            # Check only buses in the grid, not those already in slots (as they are 'stuck' or 'ready')
            buses_in_grid_to_check = [b for b in self.all_buses if not b.is_at_boarding_slot]
            
            if not buses_in_grid_to_check and len(self.passengers_waiting) > 0:
                print("DEADLOCK INICIAL: Não há autocarros no grid principal para resgatar passageiros.")
                continue


            for bus_in_grid in buses_in_grid_to_check:
                # _can_bus_reach_any_free_slot agora retorna True/False e já faz a validação de slot
                if self._can_bus_reach_any_free_slot(bus_in_grid):
                    can_any_bus_reach_a_slot = True
                    break

            if can_any_bus_reach_a_slot or len(self.passengers_waiting) == 0:
                print(
                    "Configuração gerada: Pelo menos um autocarro pode alcançar um slot livre (ou não há passageiros para embarcar). (OK)"
                )
                print(
                    f"Configuração inicial gerada: {len(self.all_buses)} autocarros totais, {len([b for b in self.all_buses if not b.is_at_boarding_slot])} autocarros no grid, {len(self.passengers_waiting)} passageiros esperando."
                )
                return

            print("Configuração gerada resultou em deadlock inicial. Retentando...")

        print(
            f"Aviso: Não foi possível gerar uma configuração inicial sem deadlock após {max_attempts} tentativas."
        )
        print(
            f"Configuração inicial final: {len(self.all_buses)} autocarros totais, {len([b for b in self.all_buses if not b.is_at_boarding_slot])} autocarros no grid, {len(self.passengers_waiting)} passageiros esperando."
        )

    def get_possible_moves(self, bus: "Bus"):
        """
        Retorna uma lista de novas posições possíveis para o autocarro (apenas um passo),
        respeitando a sua direção fixa e obstáculos.
        Inclui movimentos para fora do grid principal para slots de embarque se forem adjacentes e livres.
        """
        possible_moves = []
        if bus.current_position is None:
            return []

        original_row, original_col = bus.current_position
        
        # Temporariamente remove o autocarro para calcular movimentos sem que ele se bloqueie
        self._clear_bus_from_all_current_positions(bus)

        # 1. Movimentos DENTRO do grid principal
        dr, dc = 0, 0
        if bus.direction == 'right':
            dc = 1
        elif bus.direction == 'left':
            dc = -1
        elif bus.direction == 'down':
            dr = 1
        elif bus.direction == 'up':
            dr = -1

        new_pos_in_grid = (original_row + dr, original_col + dc)
        
        # Verifica se o movimento é para uma célula DENTRO do grid principal
        if (0 <= new_pos_in_grid[0] < self.rows and 0 <= new_pos_in_grid[1] < self.cols):
            # Se sim, verifica se a área está livre dentro do grid
            if self.is_area_free(new_pos_in_grid, bus.size, bus_to_ignore=None):
                possible_moves.append(new_pos_in_grid)

        # 2. Movimentos PARA os slots de embarque (se o autocarro estiver na fronteira)
        
        # Obter as coordenadas das células do autocarro na sua posição atual
        bus_cells = []
        start_r, start_c = original_row, original_col
        rows_occupied, cols_occupied = bus.size
        for r_offset in range(rows_occupied):
            for c_offset in range(cols_occupied):
                bus_cells.append((start_r + r_offset, start_c + c_offset))


        # Verificar se alguma parte do autocarro (na sua posição atual) toca uma das 4 fronteiras do GRID PRINCIPAL
        # Um autocarro está "na fronteira" se a sua caixa delimitadora se sobrepõe à fronteira.
        touching_border = False
        if bus.direction == 'up' and start_r == 0: touching_border = True
        if bus.direction == 'down' and start_r + rows_occupied - 1 == self.rows - 1: touching_border = True
        if bus.direction == 'left' and start_c == 0: touching_border = True
        if bus.direction == 'right' and start_c + cols_occupied - 1 == self.cols - 1: touching_border = True

        if touching_border:
            # Verifica se há algum slot livre adjacente na direção do autocarro
            for slot_pos, bus_in_slot in self.boarding_slots.items():
                if bus_in_slot is None: # Slot está livre
                    slot_r, slot_c = slot_pos

                    # Lógica de adjacência: o slot deve estar na direção de saída do autocarro
                    is_slot_valid_exit_target = False

                    if bus.direction == 'up' and slot_r == -1:
                        # Slot superior, verifica se está alinhado horizontalmente com o autocarro
                        if any(c_val == slot_c for _, c_val in bus_cells):
                            is_slot_valid_exit_target = True
                            
                    elif bus.direction == 'down' and slot_r == self.rows:
                        # Slot inferior, verifica se está alinhado horizontalmente com o autocarro
                        if any(c_val == slot_c for _, c_val in bus_cells):
                            is_slot_valid_exit_target = True

                    elif bus.direction == 'left' and slot_c == -1:
                        # Slot esquerdo, verifica se está alinhado verticalmente com o autocarro
                        if any(r_val == slot_r for r_val, _ in bus_cells):
                            is_slot_valid_exit_target = True
                            
                    elif bus.direction == 'right' and slot_c == self.cols:
                        # Slot direito, verifica se está alinhado verticalmente com o autocarro
                        if any(r_val == slot_r for r_val, _ in bus_cells):
                            is_slot_valid_exit_target = True
                    
                    # --- Casos de Canto para Slots ---
                    # Um autocarro num canto pode alcançar um slot de canto *se a sua direção o permitir*.
                    # Se o autocarro está no canto do grid principal E o slot é o slot de canto correspondente
                    # E o autocarro está virado para a direção desse canto.
                    
                    if bus.direction == 'up' and (start_r == 0 and start_c == 0) and (slot_r == -1 and slot_c == -1):
                        is_slot_valid_exit_target = True
                    if bus.direction == 'left' and (start_r == 0 and start_c == 0) and (slot_r == -1 and slot_c == -1):
                        is_slot_valid_exit_target = True

                    if bus.direction == 'up' and (start_r == 0 and start_c + cols_occupied - 1 == self.cols - 1) and (slot_r == -1 and slot_c == self.cols):
                        is_slot_valid_exit_target = True
                    if bus.direction == 'right' and (start_r == 0 and start_c + cols_occupied - 1 == self.cols - 1) and (slot_r == -1 and slot_c == self.cols):
                        is_slot_valid_exit_target = True

                    if bus.direction == 'down' and (start_r + rows_occupied - 1 == self.rows - 1 and start_c == 0) and (slot_r == self.rows and slot_c == -1):
                        is_slot_valid_exit_target = True
                    if bus.direction == 'left' and (start_r + rows_occupied - 1 == self.rows - 1 and start_c == 0) and (slot_r == self.rows and slot_c == -1):
                        is_slot_valid_exit_target = True
                        
                    if bus.direction == 'down' and (start_r + rows_occupied - 1 == self.rows - 1 and start_c + cols_occupied - 1 == self.cols - 1) and (slot_r == self.rows and slot_c == self.cols):
                        is_slot_valid_exit_target = True
                    if bus.direction == 'right' and (start_r + rows_occupied - 1 == self.rows - 1 and start_c + cols_occupied - 1 == self.cols - 1) and (slot_r == self.rows and slot_c == self.cols):
                        is_slot_valid_exit_target = True

                    if is_slot_valid_exit_target:
                        possible_moves.append(slot_pos)
                        print(f"DEBUG get_possible_moves: Adicionando slot {slot_pos} como movimento possível para bus em {original_row, original_col} (dir: {bus.direction})")


        # Re-coloca o autocarro na sua posição original após a simulação
        self.place_bus(bus, (original_row, original_col))

        return possible_moves

    def is_deadlocked(self):
        """
        Verifica se o jogo está em um estado de deadlock ou vitória.
        Retorna (True/False, "Mensagem")
        """
        # A victory condition is met if there are no passengers waiting AND
        # all buses are either gone (departed) or currently in a slot, full, and ready to leave.
        if not self.passengers_waiting:
            all_buses_are_departed_or_ready_to_depart = True
            for bus in self.all_buses:
                if bus.is_at_boarding_slot:
                    if not (bus.is_full() and bus.all_passengers_match_color()):
                        all_buses_are_departed_or_ready_to_depart = False
                        break
                else: # Bus is in the main grid
                    # If there are no passengers, and a bus is in the grid, it implies it might be stuck
                    # unless it can reach a slot (even if it doesn't need to board passengers).
                    if not self._can_bus_reach_any_free_slot(bus): # THIS METHOD WAS MODIFIED
                        all_buses_are_departed_or_ready_to_depart = False
                        break
            
            if all_buses_are_departed_or_ready_to_depart:
                if not self.all_buses: # All buses have departed and no passengers waiting
                    return (
                        False,
                        "Parabéns! Todos os passageiros embarcaram e todos os autocarros completaram suas viagens!"
                    )
                else: # No passengers, but some buses are still waiting in slots to depart
                     return (
                        False,
                        "Parabéns! Todos os passageiros embarcaram. Complete a viagem dos autocarros restantes!"
                    )

            else:
                return (
                    True,
                    "Fim de Jogo: Não há mais passageiros esperando, mas alguns autocarros estão presos ou não conseguem completar a tarefa (sair do parque)."
                )

        # If there are passengers waiting, check if any bus can reach a slot.
        # If no bus can reach a slot, it's a deadlock.
        can_any_bus_reach_any_slot = False
        for bus_in_grid in [
            b for b in self.all_buses if not b.is_at_boarding_slot
        ]:
            if self._can_bus_reach_any_free_slot(bus_in_grid): # THIS METHOD WAS MODIFIED
                can_any_bus_reach_any_slot = True
                break

        if self.passengers_waiting and not can_any_bus_reach_any_slot:
            return (
                True,
                "DEADLOCK: Passageiros esperando, mas nenhum autocarro consegue sair para um slot de embarque livre."
            )

        return False, "Jogo em progresso."


# --- Nova Classe: BoardView ---
class BoardView(QWidget):
    """
    Widget PySide6 responsável por desenhar o tabuleiro de jogo, autocarros,
    passageiros e slots de embarque.
    """

    def __init__(self, game_window: "GameWindow", parent=None):
        super().__init__(parent)
        self.game_window = game_window
        self.board = None
        self.cell_size = 60
        self.setMouseTracking(True)

        # Definir offsets para permitir que os slots na borda (-1,-1) sejam visíveis
        # Estes offsets garantem uma margem de uma célula em cada lado do tabuleiro principal
        self.offset_x = self.cell_size
        self.offset_y = self.cell_size

        self.color_map = {
            "red": QColor(255, 100, 100),
            "blue": QColor(100, 100, 255),
            "green": QColor(100, 255, 100),
            "purple": QColor(200, 100, 200),
            "orange": QColor(255, 165, 0),
            "cyan": QColor(0, 255, 255),
            "magenta": QColor(255, 0, 255),
            "grey": QColor(180, 180, 180),
            "dark_grey": QColor(100, 100, 100),
            "slot": QColor(150, 255, 150),
            "occupied_slot": QColor(100, 200, 100),
            "purple_and_lilac": QColor(180, 150, 250), # Nova cor para o exemplo
            "lilac": QColor(200, 160, 255),  # lilás claro
        }

    def set_board(self, board_instance: "Board"):
        """Define o objeto Board que este widget deve renderizar."""
        self.board = board_instance
        # Ajusta o tamanho da janela para acomodar tabuleiro + margens para slots
        # O +2 aqui é para a margem de 1 célula em cada lado (top/bottom, left/right)
        self.setMinimumSize(
            self.cell_size * (self.board.cols + 2) + 200, # Adicionar mais espaço para passageiros na direita
            self.cell_size * (self.board.rows + 2)
        )
        self.update()

    def paintEvent(self, event):
        """
        Método de desenho principal para o widget.
        """
        if not self.board:
            return

        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        board_rows = self.board.rows
        board_cols = self.board.cols

        # Draw main grid cells
        for r in range(board_rows):
            for c in range(board_cols):
                rect = QRectF(
                    c * self.cell_size + self.offset_x,  # Aplicar offset
                    r * self.cell_size + self.offset_y,  # Aplicar offset
                    self.cell_size,
                    self.cell_size,
                )

                painter.setBrush(QBrush(self.color_map["grey"]))
                painter.setPen(QPen(self.color_map["dark_grey"], 1))
                painter.drawRect(rect)

        # Draw boarding slots
        for pos, bus_in_slot in self.board.boarding_slots.items():
            r, c = pos
            # Ajusta as coordenadas para desenhar slots fora do grid principal
            draw_x = c * self.cell_size
            draw_y = r * self.cell_size

            # Ajustar a posição de desenho dos slots usando os offsets
            if c == -1: # Left border slot
                draw_x = 0 # O slot -1, c será desenhado na coluna 0 de pixels
            elif c == self.board.cols: # Right border slot
                draw_x = (self.board.cols + 1) * self.cell_size # O slot cols, r será desenhado na coluna (cols+1) de pixels
            else: # Slot column is within main grid columns (0 to cols-1)
                draw_x = (c + 1) * self.cell_size # Shift by 1 cell because of left offset


            if r == -1: # Top border slot
                draw_y = 0 # O slot r, -1 será desenhado na linha 0 de pixels
            elif r == self.board.rows: # Bottom border slot
                draw_y = (self.board.rows + 1) * self.cell_size # O slot r, rows será desenhado na linha (rows+1) de pixels
            else: # Slot row is within main grid rows (0 to rows-1)
                draw_y = (r + 1) * self.cell_size # Shift by 1 cell because of top offset

            rect = QRectF(
                draw_x,
                draw_y,
                self.cell_size,
                self.cell_size,
            )

            if bus_in_slot:
                painter.setBrush(QBrush(self.color_map["occupied_slot"]))
            else:
                painter.setBrush(QBrush(self.color_map["slot"]))

            painter.setPen(QPen(self.color_map["dark_grey"], 2))
            painter.drawRect(rect)

            font = QFont("Arial", 8)
            painter.setFont(font)
            painter.setPen(Qt.black)
            if not bus_in_slot:
                painter.drawText(rect, Qt.AlignCenter, "SLOT")

        # Draw buses
        for bus in self.board.all_buses:
            if bus.current_position:
                # Use animated_position if available for smooth movement, otherwise use current_position
                # animated_position e current_position são ambos em coordenadas lógicas (grid/slot)
                draw_pos_logical_r, draw_pos_logical_c = bus.animated_position if bus.animated_position else bus.current_position

                # Convert logical coordinates to pixel coordinates for drawing
                # This logic is crucial for visibility
                draw_x_pixel = 0
                draw_y_pixel = 0

                if bus.is_at_boarding_slot:
                    # If bus is in a slot, its size is 1x1 cell visually
                    bus_total_width = self.cell_size
                    bus_total_height = self.cell_size

                    if draw_pos_logical_c == -1: # Left border slot
                        draw_x_pixel = 0
                    elif draw_pos_logical_c == self.board.cols: # Right border slot
                        draw_x_pixel = (self.board.cols + 1) * self.cell_size
                    else: # Column within main grid
                        draw_x_pixel = (draw_pos_logical_c + 1) * self.cell_size

                    if draw_pos_logical_r == -1: # Top border slot
                        draw_y_pixel = 0
                    elif draw_pos_logical_r == self.board.rows: # Bottom border slot
                        draw_y_pixel = (self.board.rows + 1) * self.cell_size
                    else: # Row within main grid
                        draw_y_pixel = (draw_pos_logical_r + 1) * self.cell_size
                else:
                    # Bus is in the main grid, use its actual size and apply offsets
                    rows_occupied, cols_occupied = bus.size
                    bus_total_width = cols_occupied * self.cell_size
                    bus_total_height = rows_occupied * self.cell_size
                    
                    draw_x_pixel = draw_pos_logical_c * self.cell_size + self.offset_x
                    draw_y_pixel = draw_pos_logical_r * self.cell_size + self.offset_y


                bus_color = self.color_map.get(bus.color, QColor(0, 0, 0))
                painter.setBrush(QBrush(bus_color))
                painter.setPen(QPen(Qt.black, 2))

                bus_rect = QRectF(
                    draw_x_pixel,
                    draw_y_pixel,
                    bus_total_width,
                    bus_total_height,
                )

                painter.drawRoundedRect(bus_rect, 10, 10)

                # Draw passenger count on bus
                painter.setPen(Qt.white)
                font = QFont("Arial", 12, QFont.Bold)
                painter.setFont(font)
                painter.drawText(
                    bus_rect, Qt.AlignCenter, f"{len(bus.passengers)}/{bus.capacity}"
                )

                # Draw directional arrows on bus (only if not in a slot to avoid clutter)
                if not bus.is_at_boarding_slot:
                    arrow_color = QColor(255, 255, 0)
                    painter.setPen(QPen(arrow_color, 3, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin))
                    painter.setBrush(QBrush(arrow_color))

                    center_x = bus_rect.center().x()
                    center_y = bus_rect.center().y()
                    arrow_length = self.cell_size * 0.4
                    arrow_head_size = self.cell_size * 0.15

                    # Setas direcionais para cada uma das 4 direções
                    if bus.direction == 'right':
                        # Arrow right
                        start_arrow = QPointF(bus_rect.right() - arrow_length, center_y) 
                        end_arrow = QPointF(bus_rect.right(), center_y) 
                        painter.drawLine(start_arrow, end_arrow)
                        arrow_head = QPolygonF([
                            QPointF(end_arrow.x(), end_arrow.y()),
                            QPointF(end_arrow.x() - arrow_head_size, end_arrow.y() - arrow_head_size),
                            QPointF(end_arrow.x() - arrow_head_size, end_arrow.y() + arrow_head_size),
                        ])
                        painter.drawPolygon(arrow_head)
                    elif bus.direction == 'left':
                        # Arrow left
                        start_arrow = QPointF(bus_rect.left() + arrow_length, center_y) 
                        end_arrow = QPointF(bus_rect.left(), center_y) 
                        painter.drawLine(start_arrow, end_arrow)
                        arrow_head = QPolygonF([
                            QPointF(end_arrow.x(), end_arrow.y()),
                            QPointF(end_arrow.x() + arrow_head_size, end_arrow.y() - arrow_head_size),
                            QPointF(end_arrow.x() + arrow_head_size, end_arrow.y() + arrow_head_size),
                        ])
                        painter.drawPolygon(arrow_head)
                    elif bus.direction == 'down':
                        # Arrow down
                        start_arrow = QPointF(center_x, bus_rect.bottom() - arrow_length) 
                        end_arrow = QPointF(center_x, bus_rect.bottom()) 
                        painter.drawLine(start_arrow, end_arrow)
                        arrow_head = QPolygonF([
                            QPointF(end_arrow.x(), end_arrow.y()),
                            QPointF(end_arrow.x() - arrow_head_size, end_arrow.y() - arrow_head_size),
                            QPointF(end_arrow.x() + arrow_head_size, end_arrow.y() - arrow_head_size),
                        ])
                        painter.drawPolygon(arrow_head)
                    elif bus.direction == 'up':
                        # Arrow up
                        start_arrow = QPointF(center_x, bus_rect.top() + arrow_length) 
                        end_arrow = QPointF(center_x, bus_rect.top()) 
                        painter.drawLine(start_arrow, end_arrow)
                        arrow_head = QPolygonF([
                            QPointF(end_arrow.x(), end_arrow.y()),
                            QPointF(end_arrow.x() - arrow_head_size, end_arrow.y() + arrow_head_size),
                            QPointF(end_arrow.x() + arrow_head_size, end_arrow.y() + arrow_head_size),
                        ])
                        painter.drawPolygon(arrow_head)


        # Draw selection highlight
        if self.game_window.selected_bus:
            selected_bus = self.game_window.selected_bus
            # Check if the selected bus is still on the board or in a slot
            if selected_bus.current_position:
                # Use current_position for highlight as it's the target
                start_row_logical, start_col_logical = selected_bus.current_position 
                
                painter.setPen(QPen(QColor(255, 255, 0), 4)) # Yellow highlight
                painter.setBrush(Qt.NoBrush)

                # CÁLCULO DE POSIÇÃO PARA HIGHLIGHT EM SLOTS E NO GRID
                draw_x_pixel = 0
                draw_y_pixel = 0

                if selected_bus.is_at_boarding_slot:
                    if start_col_logical == -1: # Left border slot
                        draw_x_pixel = 0
                    elif start_col_logical == self.board.cols: # Right border slot
                        draw_x_pixel = (self.board.cols + 1) * self.cell_size
                    else: # Column within main grid
                        draw_x_pixel = (start_col_logical + 1) * self.cell_size

                    if start_row_logical == -1: # Top border slot
                        draw_y_pixel = 0
                    elif start_row_logical == self.board.rows: # Bottom border slot
                        draw_y_pixel = (self.board.rows + 1) * self.cell_size
                    else: # Row within main grid
                        draw_y_pixel = (start_row_logical + 1) * self.cell_size

                    rect = QRectF(
                        draw_x_pixel,
                        draw_y_pixel,
                        self.cell_size,
                        self.cell_size,
                    )
                    painter.drawRect(rect)
                else: # No grid principal
                    rows_occupied, cols_occupied = selected_bus.size
                    bus_total_width = cols_occupied * self.cell_size
                    bus_total_height = rows_occupied * self.cell_size
                    bus_rect = QRectF(
                        start_col_logical * self.cell_size + self.offset_x,
                        start_row_logical * self.cell_size + self.offset_y,
                        bus_total_width,
                        bus_total_height,
                    )
                    painter.drawRoundedRect(bus_rect, 10, 10)


        # Draw waiting passengers (ajustar posição para levar em conta os offsets)
        passenger_x_offset = (self.board.cols + 2) * self.cell_size + 20 # Desloca mais para a direita
        passenger_y_start = self.offset_y + self.cell_size * 0.2
        passenger_dot_size = self.cell_size * 0.2
        passenger_y_offset = (
            self.cell_size * 0.3
        )

        font_passenger_count = QFont("Arial", 14, QFont.Bold)
        painter.setFont(font_passenger_count)
        painter.setPen(Qt.white)
        painter.drawText(
            int(passenger_x_offset - self.cell_size * 0.5),
            int(passenger_y_start - self.cell_size * 0.8),  # Levanta o texto
            f"Esperando: {len(self.board.passengers_waiting)}"
)


        # Display first few passengers
        for i, passenger in enumerate(self.board.passengers_waiting[:10]): # Limit to 10 for visibility
            passenger_color = self.color_map.get(
                passenger.color, QColor(0, 0, 0)
            )
            painter.setBrush(QBrush(passenger_color))
            painter.setPen(Qt.NoPen)

            x = passenger_x_offset
            y = passenger_y_start + i * passenger_y_offset
            painter.drawEllipse(
                QPointF(x, y), passenger_dot_size / 2, passenger_dot_size / 2
            )

        painter.end()

    def mousePressEvent(self, event):
        """
        Lida com cliques do mouse no tabuleiro.
        Ajusta a deteção do clique para ter em conta o offset.
        """
        if event.button() == Qt.LeftButton:
            # Posições de clique em pixels (do evento)
            click_x_pixel = event.position().x()
            click_y_pixel = event.position().y()

            clicked_row_logical = -999 # Valor inicial para debugging
            clicked_col_logical = -999 # Valor inicial para debugging

            # Determinar a célula lógica clicada, incluindo slots externos
            # Top row slot
            if click_y_pixel < self.offset_y:
                clicked_row_logical = -1
                if 0 <= click_x_pixel - self.offset_x < self.board.cols * self.cell_size:
                    clicked_col_logical = int((click_x_pixel - self.offset_x) / self.cell_size)
                elif click_x_pixel < self.offset_x: # Top-left corner slot
                    clicked_col_logical = -1
                elif click_x_pixel >= self.offset_x + self.board.cols * self.cell_size: # Top-right corner slot
                    clicked_col_logical = self.board.cols
            # Bottom row slot
            elif click_y_pixel >= self.offset_y + self.board.rows * self.cell_size:
                clicked_row_logical = self.board.rows
                if 0 <= click_x_pixel - self.offset_x < self.board.cols * self.cell_size:
                    clicked_col_logical = int((click_x_pixel - self.offset_x) / self.cell_size)
                elif click_x_pixel < self.offset_x: # Bottom-left corner slot
                    clicked_col_logical = -1
                elif click_x_pixel >= self.offset_x + self.board.cols * self.cell_size: # Bottom-right corner slot
                    clicked_col_logical = self.board.cols
            # Left column slot
            elif click_x_pixel < self.offset_x:
                clicked_col_logical = -1
                if 0 <= click_y_pixel - self.offset_y < self.board.rows * self.cell_size:
                    clicked_row_logical = int((click_y_pixel - self.offset_y) / self.cell_size)
                # Corner cases already handled by top/bottom if-elif
            # Right column slot
            elif click_x_pixel >= self.offset_x + self.board.cols * self.cell_size:
                clicked_col_logical = self.board.cols
                if 0 <= click_y_pixel - self.offset_y < self.board.rows * self.cell_size:
                    clicked_row_logical = int((click_y_pixel - self.offset_y) / self.cell_size)
                # Corner cases already handled by top/bottom if-elif
            # Inside main grid
            else:
                clicked_row_logical = int((click_y_pixel - self.offset_y) / self.cell_size)
                clicked_col_logical = int((click_x_pixel - self.offset_x) / self.cell_size)

            clicked_pos = (clicked_row_logical, clicked_col_logical)

            clicked_bus = self.game_window.game_board.get_bus_at_position(clicked_pos)

            if clicked_bus and not self.game_window.is_animating: # Prevent clicks during animation
                print(f"\n--- Clicado no autocarro: {clicked_bus} ---")
                print(f"Passageiros esperando: {len(self.game_window.game_board.passengers_waiting)}")
                print(f"Estado dos slots de embarque antes da tentativa: {self.game_window.game_board.boarding_slots}")

                self.game_window.selected_bus = clicked_bus
                self.update()

                self.game_window.move_and_board_passenger(clicked_bus)
            elif self.game_window.is_animating:
                QMessageBox.warning(self, "Aguarde", "Aguarde o autocarro terminar o movimento.")
            else:
                self.game_window.selected_bus = None
                self.update()
                print(f"DEBUG: Clicado em ({clicked_row_logical}, {clicked_col_logical}) - Nenhuma autocarro encontrado.")


# --- Classe GameWindow ---
class GameWindow(QMainWindow):
    """
    A janela principal do jogo Bus Park, responsável pela interface gráfica e
    pela lógica de interação com o usuário.
    """

    def __init__(self):
        """
        Inicializa a janela do jogo e seus componentes.
        """
        super().__init__()
        self.setWindowTitle("Bus Park Game")
        self.setFixedSize(1200, 700)  # ← Janela com tamanho fixo


        self.central_widget = QWidget()
        self.setCentralWidget(self.central_widget)
        self.main_layout = QVBoxLayout(self.central_widget)

        self.game_area_layout = QHBoxLayout()
        self.main_layout.addLayout(self.game_area_layout)

        # Alterado para ter mais slots em todas as 4 bordas
        self.game_board = Board(10, 10, num_boarding_slots=8) 
        self.board_widget = BoardView(self)
        self.game_area_layout.addWidget(self.board_widget)

        self.start_button = QPushButton("Começar Jogo")
        self.start_button.clicked.connect(self.start_game)
        self.main_layout.addWidget(self.start_button)


        self.is_animating = False # Flag to prevent new moves during animation
        self.current_animated_bus = None
        self.animation_path = [] # Stores logical (row, col) coordinates for animation
        self.animation_step = 0
        self.animation_total_steps_per_cell = 10 # More steps = smoother but slower
        self.animation_interval_ms = 30 # Milliseconds per animation step

        self.animation_timer = QTimer(self)
        self.animation_timer.timeout.connect(self.animate_bus_step)


        self.board_widget.set_board(self.game_board)

        self.selected_bus = None

    def start_game(self):
        """
        Inicia um novo jogo, gerando uma configuração inicial e atualizando a interface.
        """
        if self.is_animating:
            self.animation_timer.stop()
            self.is_animating = False
            self.current_animated_bus = None
            self.animation_path = []

        # Cálculo dinâmico do número de autocarros
        board_area = self.game_board.rows * self.game_board.cols
        # Fator de preenchimento: Aprox. 50% da área do tabuleiro será ocupada por autocarros.
        # Um autocarro médio tem 3 células de comprimento.
        num_buses = int(board_area * 0.50 / 3) 
        num_buses = max(4, min(num_buses, 20)) # Min 4 autocarros, Max 20 para um 10x10 (pode ajustar)

        print(f"Tentando gerar o tabuleiro com {num_buses} autocarros para uma área de {board_area} células.")
        self.game_board.generate_initial_configuration(num_buses)
        self.board_widget.set_board(self.game_board)
        self.board_widget.update()
        self.selected_bus = None
        self.start_button.setText("Reiniciar Jogo")
        self.check_game_state()
        self.check_game_over()



    def move_and_board_passenger(self, bus_to_move: "Bus"):
        """
        Tenta mover o autocarro para o slot mais próximo e, se conseguir,
        tenta embarcar um passageiro.
        """
        if self.is_animating:
            return # Do nothing if an animation is in progress

        if bus_to_move.is_at_boarding_slot:
            print(f"Autocarro {bus_to_move.color} já está num slot. Tentando embarcar passageiro ou sair.")
            
            # Se o autocarro está cheio E todos os passageiros correspondem, ele parte
            if bus_to_move.is_full() and bus_to_move.all_passengers_match_color():
                # A lógica de partida está agora no método depart_bus
                self.depart_bus(bus_to_move)
            
            # Se o autocarro não está cheio, tenta embarcar passageiros
            elif not bus_to_move.is_full() and self.game_board.passengers_waiting:
                self._process_boarding_queue() # Tenta embarcar passageiros em QUALQUER autocarro elegível
            else:
                QMessageBox.information(
                    self,
                    "Autocarro no Slot",
                    f"Autocarro {bus_to_move.color} está no slot, mas não pode embarcar passageiros (cheio ou sem passageiros esperando) ou ainda não está pronto para partir."
                )

        else: # O autocarro está no tabuleiro principal
            print(f"Autocarro {bus_to_move.color} está no tabuleiro. Procurando caminho para a fronteira de saída e slot livre...")
            
            # O _find_path_to_exit_border AGORA retorna o caminho COMPLETO para o slot, incluindo o slot
            # se ele encontrar um slot livre e acessível pela direção do autocarro.
            path_to_exit_cells_and_slot = self._find_path_to_exit_border(bus_to_move)

            if path_to_exit_cells_and_slot:
                free_slot_found_pos = path_to_exit_cells_and_slot[-1] # A última posição do caminho é o slot

                # Clear bus from its initial position on the board BEFORE animation starts
                # This is handled by place_bus when the animation starts, but we need to ensure
                # the board state is clean for BFS. The BFS temporarily clears and restores,
                # so the actual board state here should be valid.
                
                # Prepare animation path, including the final move to the slot
                self.current_animated_bus = bus_to_move
                self.animation_path = path_to_exit_cells_and_slot # Path in grid coordinates
                self.animation_step = 0
                self.is_animating = True
                
                # Set initial animated position to current bus position for seamless start
                self.current_animated_bus.animated_position = self.current_animated_bus.current_position
                
                self.animation_timer.start(self.animation_interval_ms) # Start the animation timer
                print(f"Iniciando animação para autocarro {bus_to_move.color} para o slot {free_slot_found_pos}. Caminho de células: {self.animation_path}")
            else:
                # Fallback: tenta colocar diretamente em qualquer slot vazio (sem animação)
                for slot_pos, bus_in_slot in self.game_board.boarding_slots.items():
                    if bus_in_slot is None:
                        placed = self.game_board.place_bus(bus_to_move, slot_pos)
                        if placed:
                            QMessageBox.information(self, "Reposicionado", f"O autocarro {bus_to_move.color} foi enviado diretamente para o slot {slot_pos}.")
                            self.board_widget.update()
                            self._process_boarding_queue()
                            self.check_game_state()
                            return
                # Se nenhum slot estava livre
                QMessageBox.warning(self, "Sem Slot Livre", "Este autocarro não consegue alcançar nenhum slot de embarque livre, e todos os slots estão ocupados.")


        


    def animate_bus_step(self):
        """
        Executa um passo da animação do autocarro.
        """
        if not self.current_animated_bus or not self.animation_path:
            self.animation_timer.stop()
            self.is_animating = False
            self.current_animated_bus = None
            self.animation_path = []
            return

        cell_size = self.board_widget.cell_size
        
        # Calculate current cell index based on animation step
        current_cell_idx = self.animation_step // self.animation_total_steps_per_cell
        step_within_cell = self.animation_step % self.animation_total_steps_per_cell

        if current_cell_idx >= len(self.animation_path) - 1:
            # Animation finished
            final_target_cell = self.animation_path[-1]
            # Final placement after animation completes
            self.game_board.place_bus(self.current_animated_bus, final_target_cell)
            self.current_animated_bus.animated_position = None # Reset animated position
            self.board_widget.update()
            
            QMessageBox.information(self, "Movimento Concluído", f"Autocarro {self.current_animated_bus.color} moveu-se para o slot {final_target_cell}!")
            
            # --- CHAMADA PARA A NOVA LÓGICA DE EMBARQUE APÓS A ANIMAÇÃO ---
            self._process_boarding_queue() 
            # --- FIM DA CHAMADA ---
            
            self.animation_timer.stop()
            self.is_animating = False
            self.current_animated_bus = None
            self.animation_path = []
            self.check_game_state()
            return

        start_cell_logical = self.animation_path[current_cell_idx]
        end_cell_logical = self.animation_path[current_cell_idx + 1]

        # Calculate interpolated position in logical (grid/slot) coordinates
        # This is where we need to correctly interpolate between grid and slot coordinates
        t = step_within_cell / self.animation_total_steps_per_cell
        
        # Determine actual pixel coordinates for interpolation
        # This part maps logical coords to pixel coords for interpolation
        start_pixel_x, start_pixel_y = self._get_pixel_coords_for_logical_pos(start_cell_logical)
        end_pixel_x, end_pixel_y = self._get_pixel_coords_for_logical_pos(end_cell_logical)

        interp_pixel_x = start_pixel_x * (1 - t) + end_pixel_x * t
        interp_pixel_y = start_pixel_y * (1 - t) + end_pixel_y * t

        # Store interpolated pixel position directly for drawing
        # The Bus's animated_position is now a pixel position for drawing, not logical.
        # This is a key change for smoother animation across different coordinate systems.
        self.current_animated_bus.animated_position = (interp_pixel_y, interp_pixel_x) # (r, c) format

        self.board_widget.update()

        self.animation_step += 1

    def _get_pixel_coords_for_logical_pos(self, logical_pos: tuple):
        """
        Converte uma posição lógica (grid ou slot) para a sua posição de pixel superior-esquerda.
        Esta função é usada pela animação para interpolar.
        """
        r, c = logical_pos
        
        cell_size = self.board_widget.cell_size
        offset_x = self.board_widget.offset_x
        offset_y = self.board_widget.offset_y

        pixel_x = 0
        pixel_y = 0

        # If it's a boarding slot
        if self.game_board.is_boarding_slot(logical_pos):
            if c == -1: # Left border slot
                pixel_x = 0
            elif c == self.game_board.cols: # Right border slot
                pixel_x = (self.game_board.cols + 1) * cell_size
            else: # Column within main grid for top/bottom slots
                pixel_x = (c + 1) * cell_size

            if r == -1: # Top border slot
                pixel_y = 0
            elif r == self.game_board.rows: # Bottom border slot
                pixel_y = (self.game_board.rows + 1) * cell_size
            else: # Row within main grid for left/right slots
                pixel_y = (r + 1) * cell_size
        else:
            # If it's a main grid cell
            pixel_x = c * cell_size + offset_x
            pixel_y = r * cell_size + offset_y

        return pixel_x, pixel_y


    def _find_path_to_exit_border(self, bus: "Bus"):
        """
        Encontra o caminho mais curto para uma célula na fronteira do grid principal
        que permita ao autocarro "sair" (na sua direção), E que haja um slot de embarque
        livre *adjacente* a essa extremidade de saída do autocarro.
        Retorna a lista de posições do caminho (incluindo a posição do slot final) ou None se não houver.
        """
        original_pos = bus.current_position
        print(f"DEBUG BFS: Para autocarro {bus.color} na posição {original_pos} para encontrar saída para qualquer slot livre.")
        if original_pos is None:
            print(f"DEBUG BFS: Autocarro sem posição inicial: {bus}")
            return None

        queue = deque([(original_pos, [original_pos])])
        visited = {original_pos}

        # Simula a remoção do autocarro para calcular caminhos dentro do grid
        self.game_board._clear_bus_from_all_current_positions(bus)
        print(f"DEBUG BFS: Autocarro {bus.color} temporariamente removido para BFS de saída.")

        path_to_final_slot = None # Armazenará o caminho completo até o slot
        
        while queue:
            current_pos, path = queue.popleft()

            if len(path) > (self.game_board.rows * self.game_board.cols) * 2: # Limit to prevent infinite loops
                print("DEBUG BFS: Caminho muito longo, abortando BFS para evitar loop infinito.")
                break

            start_r, start_c = current_pos
            rows_bus, cols_bus = bus.size

            # Verificar se alguma parte do autocarro (em current_pos) toca uma das 4 fronteiras do GRID PRINCIPAL
            # Um autocarro está "na fronteira" se a sua caixa delimitadora se sobrepõe à fronteira.
            bus_is_at_grid_border = False
            # Check top edge
            if start_r == 0: bus_is_at_grid_border = True
            # Check bottom edge
            if start_r + rows_bus - 1 == self.game_board.rows - 1: bus_is_at_grid_border = True
            # Check left edge
            if start_c == 0: bus_is_at_grid_border = True
            # Check right edge
            if start_c + cols_bus - 1 == self.game_board.cols - 1: bus_is_at_grid_border = True
            
            if bus_is_at_grid_border:
                # Se o autocarro toca uma fronteira, verificamos *todos* os slots livres
                # e se algum deles é adjacente à *qualquer* parte do autocarro,
                # considerando a direção em que o autocarro está virado.

                # Determine a(s) borda(s) que o autocarro está a tocar
                touching_top = (start_r == 0)
                touching_bottom = (start_r + rows_bus - 1 == self.game_board.rows - 1)
                touching_left = (start_c == 0)
                touching_right = (start_c + cols_bus - 1 == self.game_board.cols - 1)


                for slot_pos, bus_in_slot in self.game_board.boarding_slots.items():
                    if bus_in_slot is None: # Slot está livre
                        slot_r, slot_c = slot_pos
                        is_slot_truly_adjacent = False

                        # Lógica de adjacência refinada para todos os tipos de slots e direções de autocarro
                        
                        # 1. Slots na borda superior (row = -1)
                        if slot_r == -1 and touching_top:
                            # O slot (-1, slot_c) é adjacente se 'slot_c' estiver dentro da projeção horizontal do autocarro
                            # E o autocarro está virado para cima.
                            if (start_c <= slot_c < start_c + cols_bus) and bus.direction == 'up':
                                is_slot_truly_adjacent = True
                                print(f"DEBUG BFS: Slot adjacente (-1, {slot_c}) encontrado via UP para bus em {current_pos}")

                        # 2. Slots na borda inferior (row = self.rows)
                        elif slot_r == self.game_board.rows and touching_bottom:
                            # O slot (rows, slot_c) é adjacente se 'slot_c' estiver dentro da projeção horizontal do autocarro
                            # E o autocarro está virado para baixo.
                            if (start_c <= slot_c < start_c + cols_bus) and bus.direction == 'down':
                                is_slot_truly_adjacent = True
                                print(f"DEBUG BFS: Slot adjacente ({self.game_board.rows}, {slot_c}) encontrado via DOWN para bus em {current_pos}")

                        # 3. Slots na borda esquerda (col = -1)
                        elif slot_c == -1 and touching_left:
                            # O slot (slot_r, -1) é adjacente se 'slot_r' estiver dentro da projeção vertical do autocarro
                            # E o autocarro está virado para a esquerda.
                            if (start_r <= slot_r < start_r + rows_bus) and bus.direction == 'left':
                                is_slot_truly_adjacent = True
                                print(f"DEBUG BFS: Slot adjacente ({slot_r}, -1) encontrado via LEFT para bus em {current_pos}")

                        # 4. Slots na borda direita (col = self.cols)
                        elif slot_c == self.game_board.cols and touching_right:
                            # O slot (slot_r, cols) é adjacente se 'slot_r' estiver dentro da projeção vertical do autocarro
                            # E o autocarro está virado para a direita.
                            if (start_r <= slot_r < start_r + rows_bus) and bus.direction == 'right':
                                is_slot_truly_adjacent = True
                                print(f"DEBUG BFS: Slot adjacente ({slot_r}, {self.game_board.cols}) encontrado via RIGHT para bus em {current_pos}")
                        
                        # --- Casos de Canto - Tratamento Explícito para Autocarros nos Cantos do Grid ---
                        # Um autocarro num canto do grid pode alcançar um slot de canto *se a sua direção o permitir*.

                        # Autocarro no canto superior esquerdo (0,0)
                        if (start_r == 0 and start_c == 0):
                            if slot_r == -1 and slot_c == -1: # Slot de canto superior esquerdo
                                if bus.direction == 'up' or bus.direction == 'left':
                                    is_slot_truly_adjacent = True
                                    print(f"DEBUG BFS: Slot de canto (-1, -1) adjacente via bus em {current_pos}")
                            elif slot_r == -1 and slot_c == self.game_board.cols and bus.direction == 'up': # Slot superior direito, para autocarro 0,0 virado para cima
                                # Se o autocarro 0,0 for grande o suficiente para a direita para tocar a borda direita
                                if start_c + cols_bus - 1 == self.game_board.cols -1:
                                    is_slot_truly_adjacent = True
                                    print(f"DEBUG BFS: Slot de canto (-1, {self.game_board.cols}) adjacente via bus em {current_pos} (from 0,0)")
                            elif slot_c == -1 and slot_r == self.game_board.rows and bus.direction == 'left': # Slot inferior esquerdo, para autocarro 0,0 virado para esquerda
                                # Se o autocarro 0,0 for grande o suficiente para baixo para tocar a borda inferior
                                if start_r + rows_bus - 1 == self.game_board.rows -1:
                                    is_slot_truly_adjacent = True
                                    print(f"DEBUG BFS: Slot de canto ({self.game_board.rows}, -1) adjacente via bus em {current_pos} (from 0,0)")

                        # Autocarro no canto superior direito (0, cols-bus_cols)
                        elif (start_r == 0 and start_c + cols_bus - 1 == self.game_board.cols - 1):
                            if slot_r == -1 and slot_c == self.game_board.cols: # Slot de canto superior direito
                                if bus.direction == 'up' or bus.direction == 'right':
                                    is_slot_truly_adjacent = True
                                    print(f"DEBUG BFS: Slot de canto (-1, {self.game_board.cols}) adjacente via bus em {current_pos}")
                            elif slot_r == -1 and slot_c == -1 and bus.direction == 'up': # Slot superior esquerdo, para autocarro 0,cols-bus_cols virado para cima
                                if start_c == 0: # Only if bus actually spans all cols to the left
                                    is_slot_truly_adjacent = True
                                    print(f"DEBUG BFS: Slot de canto (-1, -1) adjacente via bus em {current_pos} (from 0,cols-bus_cols)")
                            elif slot_c == self.game_board.cols and slot_r == self.game_board.rows and bus.direction == 'right': # Slot inferior direito, para autocarro 0,cols-bus_cols virado para direita
                                if start_r + rows_bus - 1 == self.game_board.rows -1:
                                    is_slot_truly_adjacent = True
                                    print(f"DEBUG BFS: Slot de canto ({self.game_board.rows}, {self.game_board.cols}) adjacente via bus em {current_pos} (from 0,cols-bus_cols)")

                        # Autocarro no canto inferior esquerdo (rows-bus_rows, 0)
                        elif (start_r + rows_bus - 1 == self.game_board.rows - 1 and start_c == 0):
                            if slot_r == self.game_board.rows and slot_c == -1: # Slot de canto inferior esquerdo
                                if bus.direction == 'down' or bus.direction == 'left':
                                    is_slot_truly_adjacent = True
                                    print(f"DEBUG BFS: Slot de canto ({self.game_board.rows}, -1) adjacente via bus em {current_pos}")
                            elif slot_r == self.game_board.rows and slot_c == self.game_board.cols and bus.direction == 'down': # Slot inferior direito, para autocarro rows-bus_rows,0 virado para baixo
                                if start_c + cols_bus - 1 == self.game_board.cols -1:
                                    is_slot_truly_adjacent = True
                                    print(f"DEBUG BFS: Slot de canto ({self.game_board.rows}, {self.game_board.cols}) adjacente via bus em {current_pos} (from rows-bus_rows,0)")
                            elif slot_c == -1 and slot_r == -1 and bus.direction == 'left': # Slot superior esquerdo, para autocarro rows-bus_rows,0 virado para esquerda
                                if start_r == 0:
                                    is_slot_truly_adjacent = True
                                    print(f"DEBUG BFS: Slot de canto (-1, -1) adjacente via bus em {current_pos} (from rows-bus_rows,0)")

                        # Autocarro no canto inferior direito (rows-bus_rows, cols-bus_cols)
                        elif (start_r + rows_bus - 1 == self.game_board.rows - 1 and start_c + cols_bus - 1 == self.game_board.cols - 1):
                            if slot_r == self.game_board.rows and slot_c == self.game_board.cols: # Slot de canto inferior direito
                                if bus.direction == 'down' or bus.direction == 'right':
                                    is_slot_truly_adjacent = True
                                    print(f"DEBUG BFS: Slot de canto ({self.game_board.rows}, {self.game_board.cols}) adjacente via bus em {current_pos}")
                            elif slot_r == self.game_board.rows and slot_c == -1 and bus.direction == 'down': # Slot inferior esquerdo, para autocarro rows-bus_rows,cols-bus_cols virado para baixo
                                if start_c == 0:
                                    is_slot_truly_adjacent = True
                                    print(f"DEBUG BFS: Slot de canto ({self.game_board.rows}, -1) adjacente via bus em {current_pos} (from rows-bus_rows,cols-bus_cols)")
                            elif slot_c == self.game_board.cols and slot_r == -1 and bus.direction == 'right': # Slot superior direito, para autocarro rows-bus_rows,cols-bus_cols virado para direita
                                if start_r == 0:
                                    is_slot_truly_adjacent = True
                                    print(f"DEBUG BFS: Slot de canto (-1, {self.game_board.cols}) adjacente via bus em {current_pos} (from rows-bus_rows,cols-bus_cols)")


                        if is_slot_truly_adjacent:
                            path_to_final_slot = path + [slot_pos] # Adiciona o slot ao caminho
                            print(f"DEBUG BFS: ENCONTRADO CAMINHO DE SAÍDA E SLOT LIVRE: {current_pos} -> {slot_pos}. Caminho: {path_to_final_slot}")
                            break # Encontrou um caminho e um slot livre para sair
                
                if path_to_final_slot: # Se um slot foi encontrado e adicionado ao caminho
                    break # Termina o BFS, pois um caminho foi encontrado

            # Se não é uma posição de saída com slot livre, continua explorando dentro do grid
            
            # Temporariamente colocamos o autocarro na current_pos para calcular os "next_moves" a partir dali
            self.game_board.place_bus(bus, current_pos)
            
            # get_possible_moves SÓ RETORNA MOVS DENTRO DO GRID PRINCIPAL
            possible_next_positions = self.game_board.get_possible_moves(bus)
            
            # Agora limpamos de novo para o BFS continuar sem que o autocarro bloqueie as suas próprias células
            self.game_board._clear_bus_from_all_current_positions(bus)

            for next_pos in possible_next_positions:
                if next_pos not in visited:
                    visited.add(next_pos)
                    queue.append((next_pos, path + [next_pos]))

        # Re-coloca o autocarro na sua posição original após a simulação
        self.game_board.place_bus(bus, original_pos)
        print(f"DEBUG BFS: Autocarro {bus.color} recolocado em {original_pos}.")

        if path_to_final_slot:
            print(f"DEBUG BFS: Caminho final encontrado para saída com slot: {path_to_final_slot}")
        else:
            print("DEBUG BFS: NENHUM CAMINHO DE SAÍDA COM SLOT LIVRE ENCONTRADO.")
        
        return path_to_final_slot


    def _process_boarding_queue(self):
        """
        Processa a fila de passageiros, tentando embarcá-los nos autocarros
        disponíveis nos slots de embarque que correspondam à sua cor.
        O primeiro passageiro na fila tem prioridade.
        """
        if not self.game_board.passengers_waiting:
            print("Não há passageiros esperando na fila.")
            self.board_widget.update()
            self.check_game_state()
            return

        passenger_to_board = self.game_board.passengers_waiting[0]
        print(f"DEBUG: Tentando embarcar o primeiro passageiro: {passenger_to_board.color}")

        # Encontra todos os autocarros nos slots de embarque que não estão cheios
        # e que podem embarcar este passageiro.
        eligible_buses_in_slots = []
        for slot_pos, bus_in_slot in self.game_board.boarding_slots.items():
            if bus_in_slot and not bus_in_slot.is_full() and bus_in_slot.can_board_passenger(passenger_to_board):
                eligible_buses_in_slots.append(bus_in_slot)
        
        # Preferir um autocarro que já tenha passageiros da sua cor se a lógica for essa
        # (por enquanto, apenas o primeiro elegível serve)
        if eligible_buses_in_slots:
            # Podemos ter uma lógica mais sofisticada aqui para escolher o "melhor" autocarro,
            # mas por agora, vamos pegar o primeiro autocarro elegível que encontramos.
            bus_for_boarding = eligible_buses_in_slots[0]
            print(f"DEBUG: Passageiro {passenger_to_board.color} pode embarcar no autocarro {bus_for_boarding.color}")

            if bus_for_boarding.add_passenger(passenger_to_board):
                self.game_board.passengers_waiting.pop(0) # Remove o passageiro da fila
                self.board_widget.update()
                QMessageBox.information(
                    self, 
                    "Embarque!", 
                    f"Passageiro {passenger_to_board.color} embarcou no autocarro {bus_for_boarding.color}!"
                )
                print(f"DEBUG: Passageiro {passenger_to_board.color} embarcou. Passageiros restantes: {len(self.game_board.passengers_waiting)}")
                
                # Se o autocarro ficou cheio após este embarque, ele parte
                if bus_for_boarding.is_full() and bus_for_boarding.all_passengers_match_color():
                    self.depart_bus(bus_for_boarding)
                    return # Autocarro partiu, não há mais embarques para este autocarro agora
                
                # Se o autocarro ainda não está cheio e há mais passageiros esperando,
                # tentamos embarcar o próximo passageiro IMEDIATAMENTE no MESMO autocarro
                # ou outro autocarro elegível.
                # Chamamos recursivamente para continuar o processo.
                self._process_boarding_queue() 

            else:
                # Este caso só deve acontecer se `can_board_passenger` for True e `add_passenger` False,
                # o que seria um erro de lógica, pois `can_board_passenger` já verifica a lotação.
                QMessageBox.warning(
                    self, 
                    "Erro de Lógica", 
                    f"Passageiro {passenger_to_board.color} não pôde embarcar no autocarro {bus_for_boarding.color} inesperadamente."
                )
        else:
            QMessageBox.information(
                self,
                "Sem Autocarro para Embarque",
                f"O passageiro {passenger_to_board.color} é o primeiro da fila, mas não há autocarros elegíveis nos slots de embarque para esta cor."
            )
        
        self.board_widget.update()
        self.check_game_state()


    def depart_bus(self, bus_to_depart: "Bus"):
        """
        Remove um autocarro do jogo quando ele está cheio e pronto para partir.
        """
        if not bus_to_depart or not bus_to_depart.is_at_boarding_slot:
            return

        num_passengers_off = bus_to_depart.get_off_passengers()
        
        # Free up the slot
        if bus_to_depart.current_position in self.game_board.boarding_slots:
            self.game_board.boarding_slots[bus_to_depart.current_position] = None 
        
        # Remove bus from game's active buses
        if bus_to_depart in self.game_board.all_buses:
            self.game_board.all_buses.remove(bus_to_depart) 
        
        bus_to_depart.current_position = None
        bus_to_depart.is_at_boarding_slot = False
        bus_to_depart.animated_position = None

        QMessageBox.information(
            self,
            "Autocarro Partiu!",
            f"Autocarro {bus_to_depart.color} partiu com {num_passengers_off} passageiros! Slot liberado."
        )
        print(f"DEBUG: Autocarro {bus_to_depart.color} removed from game. Total buses remaining: {len(self.game_board.all_buses)}")
        self.board_widget.update()
        self.check_game_state()
        
        # Chama a lógica de embarque automaticamente após a partida do autocarro
        self._process_boarding_queue()


    def check_game_state(self):
        """Verifica o estado do jogo e exibe mensagens de vitória ou deadlock."""
        deadlock_status, message = self.game_board.is_deadlocked()
        if deadlock_status:
            QMessageBox.information(self, "Fim de Jogo", message)
            self.start_button.setText("Recomeçar Jogo")
        elif "Parabéns" in message:
            QMessageBox.information(self, "Vitória!", message)
            self.start_button.setText("Recomeçar Jogo")


    def keyPressEvent(self, event):
        """
        Lida com eventos de teclado (se necessário).
        """
        pass # No keyboard controls yet

    def check_game_over(self):
        if not self.board.passengers:
            return

        first_passenger = self.board.passengers[0]

        all_slots_full = all(bus is not None for bus in self.board.slots.values())

        passenger_has_option = any(
            bus.can_board(first_passenger) for bus in self.board.buses
        )

        if all_slots_full and not passenger_has_option:
            QMessageBox.critical(self, "Game Over", "Game Over: Nenhum autocarro disponível para o passageiro!")

